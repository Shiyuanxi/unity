The completed tutorials are packaged up so that you may work through them without interference with existing code. If you would like to work with the completed tutorials, you can import the packages by going to the Unity menu:

Assets > Import Package > Custom Package