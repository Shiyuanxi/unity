﻿using UnityEngine;
using System.Collections;

namespace EnhancedScrollerDemos.RemoteResourcesDemo
{
    public class Data
    {
        public Vector2 imageDimensions;
        public string imageUrl;
    }
}